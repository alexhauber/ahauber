from django.contrib import admin

from fir_artifacts_enrichment.models import ArtifactEnrichment

admin.site.register(ArtifactEnrichment)
