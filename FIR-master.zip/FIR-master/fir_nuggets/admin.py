from django.contrib import admin

from fir_nuggets.models import Nugget

admin.site.register(Nugget)
